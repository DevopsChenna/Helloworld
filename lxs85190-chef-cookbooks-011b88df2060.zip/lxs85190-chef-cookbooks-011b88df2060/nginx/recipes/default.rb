#
# Cookbook Name:: nginx
# Recipe:: default
#
# Copyright 2016, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
#

# Create a self signed certficate 

package "openssl" do
  action :install
end

package 'nginx' do
  action :install
end 

directory "/etc/nginx/ssl" do
  owner "root"
  group  "root"
  mode  0755
  action :create
end

directory "/var/www/html" do
  owner "root"
  group  "root"
  mode  0755
  action :create
  recursive true
end

log "Running : openssl genrsa -passout pass:#{node[:nginx][:sslpassphrase]} -des3 -out server.key 1024"
bash "generate certificate" do
  user "root"
  cwd node['nginx']['destination']
  code <<-EOH
        openssl genrsa -passout pass:#{node[:nginx][:sslpassphrase]} -des3 -out server.key 1024
        EOH
end

log "Running : openssl req -passin pass:#{node[:nginx][:sslpassphrase]} -subj \"/C=#{node[:nginx][:country]}/ST=#{node[:nginx][:state]}/L=#{node[:nginx][:city]}/O=#{node[:nginx][:orga]}/OU=#{node[:nginx][:depart]}/CN=#{node[:nginx][:cn]}/emailAddress=#{node[:nginx][:email]}\" -new -key server.key -out server.csr"
bash "generate signature request" do
  user "root"
  cwd node['nginx']['destination']
  code <<-EOH
        openssl req -passin pass:#{node[:nginx][:sslpassphrase]} -subj "/C=#{node[:nginx][:country]}/ST=#{node[:nginx][:state]}/L=#{node[:nginx][:city]}/O=#{node[:nginx][:orga]}/OU=#{node[:nginx][:depart]}/CN=#{node[:nginx][:cn]}/emailAddress=#{node[:nginx][:email]}" -new -key server.key -out server.csr
        EOH
end

log "Running: openssl rsa -passin pass:#{node[:nginx][:sslpassphrase]} -in server.key.org -out server.key"
bash "sign key" do
  user "root"
  cwd node['nginx']['destination']
  code <<-EOH
        cp server.key server.key.org
        openssl rsa -passin pass:#{node[:nginx][:sslpassphrase]} -in server.key.org -out server.key
        EOH
end

log "Running: openssl x509 -req -days 365 -in server.csr -signkey server.key -out server.crt"
bash "signing the certificate" do
  user "root"
  cwd node['nginx']['destination']
  code <<-EOH
        openssl x509 -req -days 365 -in server.csr -signkey server.key -out server.crt
        EOH
end

cookbook_file "/etc/nginx/nginx.conf" do
  source "nginx.conf"
  mode   "0644"
end

file "/etc/nginx/nginx.conf.default" do
  action :delete
end

cookbook_file "/etc/nginx/conf.d/virtual.conf" do
	source "virtual.conf"
	mode "0644"
end 

cookbook_file "/var/www/html/index.html" do
	source "index.html"
	mode "0644"
end

service 'nginx' do
  action [ :enable, :reload]
end
